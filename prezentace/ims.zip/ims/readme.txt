Dokumenty k priprave na zkousku z IMS.

Nejake casto se objevujici se priklady a nejaka teorie. Leden 2015 prilis teorie nemel,
napr. ja mel otazku na Fuzzy:
Strucne popiste spojity regulator a demonstrujte na prikladu. Jak vypada funkce AND
ve fuzzy logice?
Stacilo popsat fuzzifikace, inference pravidel, agregace a defuzzifikace. Jeden kratky
priklad a and je MIN(a, b).

Tohle mi v dobe pripravy na zkousku prislo vtipne:
http://www.grapheine.com/bombaytv/agency-en-6ed488b2e69abf5462d84fcc62960574.html
Ted uz ale opravdu ne...
