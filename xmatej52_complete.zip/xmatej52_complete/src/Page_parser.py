from Page_reader import Page_reader
import multiprocessing
import pexpect
from time import sleep

class Page_parser( object ):
    def __init__( self, tagger_bin, tagger_file, timeout=10, filename=None ):
        self._page_reader = Page_reader( filename )
        self._tagger_bin  = tagger_bin
        self._tagger_file = tagger_file
        self._timeout     = timeout

    def _morphodita( self, input_queue, output_queue ):
        sys.stderr.write( 'Process started\n' )
        ret_value = ''
        data_sent = False
        command   = self._tagger_bin + ' --input=untokenized --output=vertical ' + self._tagger_file
        process   = pexpect.spawn( command )
        process.setecho(False)
        process.readline()
        sys.stderr.write( 'Starting...\n' )
        process.timeout = 0.005
        while ( True ):
            page = input_queue.get()
            if ( page is not None ):
                for line in page.splitlines():
                    if ( line.startswith( '<' ) ):
                        if ( data_sent ):
                            data_sent   = False
                            tagged_text = ''
                            process.sendline( b'' )
                            try:
                                tagged_text = process.readline()
                                while ( True ):
                                    tagged_text = process.readline()
                                    ret_value += tagged_text.decode()
                            except pexpect.exceptions.TIMEOUT:
                                pass
                        ret_value += line + '\n'

                    else:
                        process.sendline( str.encode( line ) )
                        data_sent = True
                sys.stderr.write( 'Done\n' )
                output_queue.put( ret_value )
                ret_value = ''
            else:
                sys.stderr.write( 'Ending...\n' )
                output_queue.put( None )
                break
        sys.stderr.write( 'Exiting' )

    def __iter__( self ):
        input_queue  = multiprocessing.Queue()
        output_queue = multiprocessing.Queue()
        finished     = multiprocessing.Lock()
        finished.acquire()

        morphodita = multiprocessing.Process( target = self._morphodita, args = ( input_queue, output_queue ) )
        morphodita.start()

        for page in self._page_reader:
            input_queue.put( page.get_text() )
            try:
                while ( True ):
                    yield output_queue.get( block = False )
            except:
                pass
        input_queue.put( None )
        while ( True ):
            tagged = output_queue.get()
            if ( tagged is not None ):
                yield tagged
            else:
                break



if __name__ == '__main__':
    # input_file tagger_bin tagger_file
    import sys
    parser = Page_parser( tagger_bin = sys.argv[2], tagger_file = sys.argv[3], filename = sys.argv[1] )
    for tagged in parser:
        print( tagged )