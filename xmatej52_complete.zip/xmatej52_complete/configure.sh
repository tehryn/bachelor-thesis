#!/usr/bin/env bash
GREEN='\033[1;32m'
RED='\033[1;31m'
NC='\033[0m' # No Color

echo "Kontrola potrebnych aplikaci."
if command -v python3 &>/dev/null; then
    echo -e "${GREEN}Python 3 je nainstalovan.${NC}"
else
    echo -e "${RED}Interpret 'python3' neni nainstalovan.${NC}"
    exit 1
fi

if command -v xz &>/dev/null; then
    echo -e "${GREEN}Xz je nainstalovan.${NC}"
else
    echo -e "${RED}Aplikace 'xz' neni nainstalovana.${NC}"
    exit 1
fi

if command -v pip3 &>/dev/null; then
    echo -e "${GREEN}Pip3 je nainstalovan${NC}"
else
    echo -e "${RED}Aplikace 'pip3' neni nainstalovana.${NC}"
    exit 1
fi

echo "Kontrola dostupnosti balicku warc, warc3 a langdetect."
python3 -c "import warc" &>/dev/null
if [ $? == 0 ]; then
   echo -e "${GREEN}Warc je jiz nainstalovan.${NC}"
else
   echo "Instaluji warc..."
   pip3 install warc
   if [ $? == 0 ]; then
      echo -e "${GREEN}Warc byl uspesne nainstalovan.${NC}"
   else
      echo -e "${RED}Nepodarilo se nainstalovat knihovnu warc.${NC}"
   fi
fi


python3 -c "import warc3" &>/dev/null
if [ $? == 0 ]; then
   echo -e "${GREEN}Warc3 je jiz nainstalovan.${NC}"
else
   echo "Instaluji warc3..."
   pip3 install warc3
   if [ $? == 0 ]; then
      echo -e "${GREEN}Warc3 byl uspesne nainstalovan.${NC}"
   else
      echo -e "${RED}Nepodarilo se nainstalovat knihovnu warc3.${NC}"
   fi
fi

python3 -c "import langdetect" &>/dev/null
if [ $? == 0 ]; then
   echo -e "${GREEN}Langdetect je jiz nainstalovan.${NC}"
else
   echo -e "Instaluji langdetect..."
   pip3 install langdetect
   if [ $? == 0 ]; then
      echo -e "${GREEN}Langdetect byl uspesne nainstalovan.${NC}"
   else
      echo -e "${RED}Nepodarilo se nainstalovat knihovnu langdetect.${NC}"
   fi
fi

echo "Vytvarim ukazkovy priklad do slozky rss_sources."
mkdir -p rss_sources
echo "http://servis.idnes.cz/rss.aspx" >rss_sources/example.txt

echo "Kontroluji dostupnost externich binarnich souboru."

if [ -f "./libary.zip" ]
then
        echo -e "${GREEN}Vytvarim/aktualizuji knihovnu...${NC}"
	unzip -o './libary.zip'
else
        echo "${RED}Komprimovana verze knihovny nebyla nalezena - nelze aktualizovat/vytvorit knihovnu.${NC}"
fi


if [ -f "./libary/morphodita/precompiled_bin/run_tokenizer" ]
then
	echo -e "${GREEN}Tokenizer byl nalezen.${NC}"
else
	echo -e "${RED}Binarni soubor tokenizeru nebyl nalezen - './libary/morphodita/precompiled_bin/run_tokenizer'.${NC}"
fi

if [ -f "./libary/morphodita/precompiled_bin/run_tagger" ]
then
        echo -e "${GREEN}Tagger byl nalezen.${NC}"
else
        echo -e "${RED}Pozor! Binerni soubor tokenizeru nebyl nalezen - './libary/morphodita/precompiled_bin/run_tagger'.${NC}"
fi

echo "Kontroluji dostupnost zakladnich jazykovych modelu."
if [ -f "./libary/morphodita/models/en.tagger" ]
then
        echo -e "${GREEN}Jazykovy model pro anglictinu byl nalezen.${NC}"
else
        echo -e "${RED}Pozor! Nebyl nalezen jazykovy model pro anglictinu - 'libary/morphodita/models/en.tagger'.${NC}"
fi

if [ -f "./libary/morphodita/models/cs.tagger" ]
then
        echo -e "${GREEN}Jazykovy model pro cestinu byl nalezen.${NC}"
else
        echo "${RED}Pozor! Nebyl nalezen jazykovy model pro cesnitnu - 'libary/morphodita/models/cs.tagger'.${NC}"
fi

if [ -f "./libary/morphodita/models/sk.tagger" ]
then
        echo -e "${GREEN}Jazykovy model pro slovenstinu byl nalezen.${NC}"
else
        echo -e "${RED}Pozor! Nebyl nalezen jazykovy model pro slovenstinu - 'libary/morphodita/models/en.tagger'${NC}."
fi
